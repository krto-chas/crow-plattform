# Crow Backbone — 0.5.0 Foundation Release

**Crow 0.5.0 är den första fungerande och externt validerade versionen av Backbone.**

Den är inte en färdig slutanvändarapplikation. Den är en stabil, separat installerbar grund som kan ta emot domänmoduler och genomföra spårbara beslutsflöden från Claim till tekniskt och kommersiellt utfall.

## Release-status

- Sprint A: avslutad
- Publika kontrakt: frysta för `0.5.x`
- Första externa domänmodul: validerad
- Separat wheel-installation: validerad
- CI och arkitekturgrindar: gröna
- Nästa milstolpe: Sprint B — Document Intelligence och Knowledge Fusion

## Vad som fungerar

```text
Claim
→ Conflict
→ AuthorityDecision / Human Review
→ AcceptedClaim
→ TechnicalDelta
→ CommercialImpact
→ ÄTA Opportunity
→ EstimateLine / ClientQuestion / Reservation
```

Backbone innehåller även:

- CrowProject som immutabel aggregatrot
- Decision Graph och Evidence Graph
- provenance och audit trail
- dokumentrevision och automatisk invalidation
- transaktionsgränser och rollback
- modul-SDK och plugin discovery
- konformitetskontroll och importskydd
- signerade modulmanifest som referensimplementation
- versionerade migrationer
- persistenskontrakt och JSON-referensimplementationer

## Extern validering

Crow Vent Reference Module `0.2.0` installerades som separat wheel tillsammans med Backbone och kördes i en ren miljö.

Referensfallet validerade:

```text
Ritning: 160 mm
Beskrivning: 200 mm
Bekräftad authority-regel: beskrivningen har företräde
Kommersiellt delta: 3 960 SEK
```

Modulen upptäcktes via entry point, klarade conformance-kontroll och använde inga privata Backbone-importer.

## Snabbstart

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e ".[dev]"
ruff check .
mypy
pytest
crow review --root . --release 0.5.0
```

På Windows aktiveras miljön med:

```powershell
.venv\Scripts\activate
```

## Scope

Version `0.5.0` använder strukturerad data. PDF-tolkning, OCR, bildanalys och AI-baserad Claim-extraktion ingår i Sprint B.

CDL och CKL är dokumenterade som framtida, fristående moduler och ingår inte i Backbone-runtime.

## Kompatibilitet

Den publika SDK- och conformance-ytan är fryst för `0.5.x`. Bakåtkompatibla tillägg får göras inom serien. Brytande kontraktsändringar kräver en ny minor- eller majorlinje enligt projektets versionspolicy.
\n## Sprint B1 quick start\n```bash\ncrow project create ./demo --name "Demo"\ncrow project import ./demo/crow-project.json ./underlag --recursive\ncrow project show ./demo/crow-project.json\n```\n
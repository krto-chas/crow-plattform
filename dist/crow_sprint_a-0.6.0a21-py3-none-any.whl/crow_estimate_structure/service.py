from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, TypedDict

from crow_estimate_line import load_estimate

from .engine import structure_estimate
from .models import (
    EstimateGroupingProfile,
    EstimateGroupingRule,
    StructuredEstimate,
)


def load_grouping_profile(path: Path) -> EstimateGroupingProfile:
    raw: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    return EstimateGroupingProfile(
        id=raw["id"],
        rules=tuple(EstimateGroupingRule(
            id=r["id"], section_code=r["section_code"],
            section_title=r["section_title"], group_code=r["group_code"],
            group_title=r["group_title"], cost_types=tuple(r.get("cost_types", [])),
            description_contains=tuple(r.get("description_contains", [])),
            priority=int(r.get("priority", 100)),
        ) for r in raw.get("rules", [])),
        fallback_section_code=raw.get("fallback_section_code", "99"),
        fallback_section_title=raw.get("fallback_section_title", "Övrigt"),
        fallback_group_code=raw.get("fallback_group_code", "99"),
        fallback_group_title=raw.get("fallback_group_title", "Ej klassificerat"),
    )

def save_structured_estimate(value: StructuredEstimate, path: Path) -> None:
    payload = json.dumps(asdict(value), ensure_ascii=False, indent=2) + "\n"
    path.write_text(payload, encoding="utf-8")

def write_grouping_profile_template(path: Path) -> None:
    payload = {
        "id": "default-estimate-structure",
        "rules": [
            {"id": "labour", "section_code": "10", "section_title": "Produktion",
             "group_code": "10", "group_title": "Arbete",
             "cost_types": ["labour"], "priority": 10},
            {"id": "material", "section_code": "10", "section_title": "Produktion",
             "group_code": "20", "group_title": "Material",
             "cost_types": ["material"], "priority": 20},
            {"id": "subcontractor", "section_code": "20", "section_title": "Underentreprenad",
             "group_code": "10", "group_title": "UE",
             "cost_types": ["subcontractor"], "priority": 30}
        ]
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

class StructuredEstimateSummary(TypedDict):
    project_id: str
    estimate_id: str
    structure_id: str
    currency: str
    sections: int
    groups: int
    lines: int
    net_total: float
    adjustment_total: float
    grand_total: float

def summarize_structured_estimate(value: StructuredEstimate) -> StructuredEstimateSummary:
    return {
        "project_id": value.project_id, "estimate_id": value.estimate_id,
        "structure_id": value.structure_id, "currency": value.currency,
        "sections": len(value.sections),
        "groups": sum(len(s.groups) for s in value.sections),
        "lines": sum(len(g.lines) for s in value.sections for g in s.groups),
        "net_total": value.net_total, "adjustment_total": value.adjustment_total,
        "grand_total": value.grand_total,
    }

def build_project_structure(
    project_file: Path, structure_id: str, profile_file: Path,
    estimate_file: Path | None = None,
) -> tuple[StructuredEstimate, Path]:
    estimate_path = estimate_file or project_file.with_name("crow-estimate.json")
    result = structure_estimate(
        load_estimate(estimate_path), load_grouping_profile(profile_file), structure_id
    )
    output = project_file.with_name("crow-structured-estimate.json")
    save_structured_estimate(result, output)
    return result, output

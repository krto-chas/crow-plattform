from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class DeltaType(StrEnum):
    ADDED = "added"
    REMOVED = "removed"
    MODIFIED = "modified"
    UNCHANGED = "unchanged"


@dataclass(frozen=True, slots=True)
class BaselineItem:
    id: str
    comparison_key: str
    category: str
    title: str
    value: str
    unit: str | None = None
    source: str = "baseline"


@dataclass(frozen=True, slots=True)
class TechnicalBaseline:
    project_id: str
    baseline_id: str
    name: str
    items: tuple[BaselineItem, ...] = ()


@dataclass(frozen=True, slots=True)
class TechnicalDeltaProvenance:
    baseline_item_id: str | None
    decision_id: str | None
    review_event_id: str | None
    accepted_claim_ids: tuple[str, ...]
    authority_decision_ids: tuple[str, ...]
    document_ids: tuple[str, ...]
    trace: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class TechnicalDelta:
    id: str
    comparison_key: str
    delta_type: DeltaType
    category: str
    title: str
    baseline_value: str | None
    approved_value: str | None
    unit: str | None
    confidence: float | None
    provenance: TechnicalDeltaProvenance
    fingerprint: str


@dataclass(frozen=True, slots=True)
class TechnicalDeltaSet:
    project_id: str
    baseline_id: str
    deltas: tuple[TechnicalDelta, ...] = ()

    @property
    def changed_count(self) -> int:
        return sum(delta.delta_type != DeltaType.UNCHANGED for delta in self.deltas)
